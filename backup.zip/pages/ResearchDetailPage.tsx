import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ExternalLinkIcon } from '../components/Icons';

// Fix: Define a comprehensive type for research details to handle optional properties like `recommendations` and ensure type safety.
type ResearchDetail = {
    title: string;
    category: string;
    headerImage: string;
    introduction: string[];
    sections: Array<{
        title: string;
        findings: Array<{
            heading: string;
            details?: string[];
            subPoints?: string[];
            table?: {
                headers: string[];
                rows: string[][];
                numericColumns?: number[];
            };
        }>;
        resources?: string[];
    }>;
    conclusion: string;
    recommendations?: {
        'For HCL': string[];
        'For the Egyptian Government': string[];
        'For Potential Partners (Local Tech Companies and Startups)': string[];
    };
    resources?: string[];
};


const researchDetails: Record<string, ResearchDetail> = {
    'global-aesthetic-markets-2025': {
        title: 'Global Aesthetic Markets 2025: Data-Driven Insights for MENA Expansion',
        category: 'Market Analysis | Aesthetics & Skincare',
        headerImage: 'https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1260&h=750&q=80',
        introduction: [
            'This document was developed in preparation for my upcoming meeting for an export-focused position within a MENA-based company. It is built upon a detailed market analysis of the global and regional aesthetic services sector, originally compiled to support strategic planning and export readiness. The goal of this research is to distil that complex dataset into actionable insights—particularly relevant for organizations seeking to expand their aesthetic portfolio across the MENA region.',
            'With a focus on high-growth segments such as injectables, skin rejuvenation, and medical-grade skincare, this document reflects how I analyse data, identify viable market opportunities, and convert them into executable strategies. It demonstrates my ability to align clinical innovation with commercial viability and adapt global trends to regional priorities.'
        ],
        sections: [
            {
                title: '1. Comprehensive Aesthetic Services Market Analysis',
                findings: [
                    {
                        heading: 'Market Overview',
                        details: ['The global aesthetic medicine market is projected to reach between $102-139 billion by 2030-2033, with strong growth rates of 8.9-12.8% CAGR. There\'s a notable surge in demand for minimally invasive and non-invasive procedures, with laser and light-based devices offering applications from hair removal to skin rejuvenation.']
                    },
                    {
                        heading: 'Regional Opportunities',
                        details: ['The Asia Pacific region shows particularly strong growth potential. Europe represents a notable market due to an increasing aging population and growing trends towards non-surgical cosmetic procedures.']
                    },
                    {
                        heading: 'Key Export Insights',
                        subPoints: [
                            'Technology Focus: Laser and light-based devices dominate with 35.2% market share.',
                            'High-Growth Segments: Hair restoration (12.3% CAGR) and advanced aesthetic technologies (13.8% CAGR).',
                            'Regional Leaders: The UK aesthetics industry alone is valued at over $3.9 billion.',
                            'Investment Returns: Training and education services offer the highest ROI potential (300-500%).'
                        ]
                    }
                ],
                resources: [
                    'https://www.towardshealthcare.com/insights/technological-advancement-in-cosmetic-procedures-boosting-the-medical-aesthetics-market-growth',
                    'https://www.grandviewresearch.com/industry-analysis/medical-aesthetics-market',
                    'https://www.rootsanalysis.com/reports/medical-aesthetics-market.html',
                ]
            },
            {
                title: '2. Comprehensive Aesthetic Dermatology Products Market Analysis',
                findings: [
                    {
                        heading: 'Market Overview',
                        details: ['The global anti-aging products market is valued at $50.92 billion in 2024 and expected to reach $78.70-80.55 billion by 2032. The facial serum market is projected to reach $10.32 billion by 2033.']
                    },
                    {
                        heading: 'Key Market Segments',
                        subPoints: [
                            'Serums Dominance: Serums and essences hold a 20% market share.',
                            'Cosmeceuticals Growth: The market is expected to reach $142.52-152.58 billion by 2032-2034.',
                            'Skin Boosters Expansion: The market is expected to grow at 10.1-13.0% CAGR to reach $2.30 billion by 2030.',
                            'Sun Care Positioning: Expected to grow to $19.9-28.96 billion by 2033-2035.'
                        ]
                    },
                     {
                        heading: 'Post-Treatment Recovery Market',
                        details: ['Valued at $20.97-23.15 billion in 2024, projected to reach $29.57-30.48 billion by 2030.']
                    }
                ],
                resources: [
                    'https://www.rootsanalysis.com/reports/advanced-wound-care-market.html',
                    'https://www.gminsights.com/industry-analysis/wound-care-market',
                ]
            },
            {
                title: '3. MENA Aesthetics Market: Brands, Key Players & Product Analysis',
                findings: [
                    {
                        heading: 'Market Overview',
                        details: ['The Middle East cosmetics market reached $18.572 billion in 2024 and is expected to reach $25.426 billion by 2033 (3.55% CAGR). The broader MENA beauty and personal care market is projected to reach $60 billion by 2025.']
                    },
                    {
                        heading: 'Leading Local Brands',
                        subPoints: ['Shiffa Beauty', 'Asteri Beauty', 'Huda Beauty', 'MZN Bodycare']
                    },
                    {
                        heading: 'Innovation Trends',
                        details: ['Key innovations include climate-adapted formulations (Asteri Beauty\'s 45 Degree Blush), and tailored skincare ranges (Peacefull\'s South Korean line for the Middle East).']
                    }
                ],
                 resources: [
                    'https://www.businessoffashion.com/articles/news-analysis/middle-eastern-women-join-the-clean-beauty-movement/',
                    'https://beautymatter.com/articles/why-the-middle-east-matters-now',
                ]
            },
            {
                title: '4. MENA Minimally Invasive Procedures & Injectables Analysis',
                findings: [
                     {
                        heading: 'Market Overview',
                        details: ['The facial injectables market is projected to grow from $9.54-$12.86 billion in 2024 to $17.24-$40.06 billion by 2030-2034 (7.7%-12.3% CAGR). Botulinum Toxin Type A dominates with 48.2% of total revenue.']
                    },
                    {
                        heading: 'Target Clinic Opportunities: UAE Premium Targets',
                        subPoints: ['Aesthetics International', 'Skin111 Clinic', 'Enhance by Mediclinic']
                    },
                    {
                        heading: 'Key Distributors',
                        subPoints: ['DUBIMED', 'ARAMED', 'Imdad']
                    },
                    {
                        heading: 'Strategic Recommendations',
                        subPoints: [
                            'Primary Target: UAE premium clinics (highest ROI potential).',
                            'Distribution Strategy: Partner with established distributors like DUBIMED or ARAMED.',
                            'Market Entry: Focus on Botox alternatives and HA fillers with unique positioning.'
                        ]
                    }
                ],
                 resources: [
                    'https://www.fortunebusinessinsights.com/industry-reports/facial-injectables-market-100603',
                    'https://market.us/report/facial-injectable-market/',
                ]
            },
        ],
        conclusion: 'The MENA injectable market presents a compelling opportunity with clear market gaps, identifiable targets, and scalable growth potential. Success requires the right local partner with established relationships, regulatory expertise, and a shared vision for market leadership. Our market intelligence indicates this is the optimal timing for entry, with first-mover advantages available in several high-growth segments.'
    },
    'egyptian-consumer-ad-survey': {
        title: 'Egyptian Consumer Ad Survey: Digital vs. Traditional Media',
        category: 'Consumer Behavior | Digital Marketing',
        headerImage: 'https://i.postimg.cc/hPyxbTvv/newplot.png',
        introduction: [
            'This survey was conducted to understand the advertising preferences and shopping behaviors of Egyptian students, a key demographic in the digital consumer landscape. The objective was to compare the effectiveness of internet versus traditional television advertising and identify the core elements that drive purchasing decisions.'
        ],
        sections: [
            {
                title: '1. Key Findings from the Survey',
                findings: [
                    {
                        heading: 'Digital Dominance: Internet Ads Preferred Over TV',
                        details: ['The survey data indicates a clear and strong preference for internet advertisements compared to traditional TV ads among the student demographic.']
                    },
                    {
                        heading: 'Ad Exposure Drives Purchases',
                        details: ['A positive correlation was found between the number of ads watched daily and the likelihood of making a purchase, suggesting that increased, targeted ad exposure can directly lead to higher purchase rates.']
                    },
                    {
                        heading: 'Diverse Shopping Behaviors',
                        details: ['The distribution of shopping behavior ratings shows a varied consumer base, with a significant number of respondents identifying as heavy shoppers, making them a prime audience for engagement.']
                    },
                    {
                        heading: 'Proven Ad Effectiveness',
                        details: ['A notable portion of respondents reported making purchases immediately after viewing advertisements, highlighting the direct impact of ads in driving consumer behavior from consideration to conversion.']
                    },
                    {
                        heading: 'Most Influential Ad Elements',
                        details: ['Key ad elements such as a clear product introduction, high-quality script, relatable actors, and the company\'s reputation were found to significantly influence consumers\' purchase decisions.']
                    }
                ]
            }
        ],
        conclusion: "The visualizations indicate that internet ads are more preferred than TV ads among Egyptian consumers. There is a positive correlation between the number of ads watched daily and the likelihood of making purchases, suggesting that increased ad exposure may lead to higher purchase rates. The distribution of shopping behavior ratings shows a varied consumer base, with a significant number identifying as heavy shoppers. Additionally, a notable portion of respondents reported making purchases after viewing advertisements, highlighting the effectiveness of ads in driving consumer behavior. Finally, key ad elements such as product introduction, script quality, actors, and company reputation significantly influence consumers' purchase decisions, with many respondents strongly agreeing on their importance."
    },
    'hcl-egypt-expansion': {
        title: "HCL's Strategic Expansion into Egypt: A Comprehensive Analysis",
        category: 'Market Entry Strategy | Tech Sector Analysis',
        headerImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1260&h=750&q=80',
        introduction: [
            "This report provides a detailed analysis of HCL Technologies' strategic expansion into the Egyptian market. The primary drivers include penetrating high-growth regions and leveraging Egypt's burgeoning technology sector. This expansion is poised to significantly influence Egypt's technology landscape by fostering competition, driving innovation, and creating substantial job opportunities."
        ],
        sections: [
            {
                title: "1. HCL's Business Strategy for Egypt",
                findings: [
                    { heading: 'Strategic Intent for High-Growth Markets', details: ["HCLSoftware has explicitly outlined its strategic intent to broaden its presence in high-growth markets spanning Africa, the Middle East, and India. Egypt naturally aligns with this objective, positioning it as a key area for expansion."] },
                    { heading: "Egypt's Compelling Advantages", subPoints: ["Competitive market wages and cost-effective operations.", "Large, skilled young population and a robust education system.", "Proactive government support for foreign investment and advanced infrastructure.", "Strategic geographic location with a central time zone for serving European and African markets."] }
                ]
            },
            {
                title: "2. Investment & Financials",
                findings: [
                    {
                        heading: 'Financial Performance of HCL Technologies Egypt Ltd (L.L.C)',
                        details: ["The data demonstrates a significant increase in the scale of HCL's operations in Egypt. Total assets grew from approximately LE 5.2 million in 2016 to over EGP 126 million by 2023, with revenues surging from LE 2.8 million to nearly EGP 128 million in the same period, indicating a growing financial commitment and expanding operational footprint."],
                        table: {
                            headers: ["Financial Indicator", "March 31, 2016 (LE)", "March 31, 2022 (EGP)", "March 31, 2023 (EGP)"],
                            rows: [
                                ["Total Assets", "5,241,823", "57,319,930", "126,149,620"],
                                ["Revenues", "2,805,659", "53,152,878", "127,748,959"],
                                ["Net Profit/(Loss)", "8,939", "2,542,711", "(2,379,168)"],
                                ["Paid-up Capital", "350,000", "4,654,190", "4,654,190"],
                            ],
                            numericColumns: [1, 2, 3],
                        }
                    }
                ]
            },
            {
                title: "3. Competitor Analysis",
                findings: [
                    {
                        heading: 'Key Technology Companies Expanding/Operating in Egypt',
                        details: ["The diverse and active competitive landscape underscores the attractiveness of the Egyptian market for technology companies. HCL will need to differentiate its offerings and leverage its global expertise to effectively compete and capture market share in this dynamic environment."],
                        table: {
                            headers: ["Company", "Primary Focus/Services", "Recent Expansion/Activities in Egypt"],
                            rows: [
                                ["Amazon", "E-commerce, Cloud Computing (AWS), AI", "Expanding operations in Cairo, focusing on AI skills training."],
                                ["IBM", "IT Support Services, Digital Transformation, AI", "Expanding presence in Cairo, involved in clean energy and AI-powered banking systems."],
                                ["Microsoft", "Software, Hardware, Cloud Services (Azure), AI", "Expanding hardware initiatives and rolling out Windows Server 2025 in Cairo."],
                                ["TTEC", "Customer Experience (CX) Technology and Services", "Recently expanded with a new site in Cairo's Maadi Technology Park."],
                                ["Concentrix", "Technology and Services Leader, Customer Engagement", "Signed an MoU with ITIDA to expand operations, aiming to create over 15,000 jobs."],
                                ["Oracle", "Enterprise Software Solutions, Cloud Services, AI", "Strong presence in Cairo's enterprise software scene."],
                                ["Teleperformance", "Global BPO", "One of the biggest names in global BPO operating in Egypt."]
                            ]
                        }
                    }
                ]
            }
        ],
        conclusion: "HCL Technologies' expansion into Egypt represents a strategic move driven by global growth objectives and the compelling opportunities in Egypt's burgeoning technology market. While facing a competitive landscape, HCL's established global expertise positions it well for success. Future projections indicate strong growth and scalability for HCL's operations in Egypt, aligning with the overall positive outlook for the nation's technology industry.",
        recommendations: {
            'For HCL': [
                'Continue to prioritize investment in local talent development through partnerships with Egyptian universities.',
                'Align service offerings with the specific needs of the Egyptian market and government-led digital transformation initiatives.',
                'Engage proactively with local media and community stakeholders to build a strong brand image.'
            ],
            'For the Egyptian Government': [
                'Sustain and enhance supportive policies and incentives to attract foreign direct investment in the technology sector.',
                'Continue to invest in educational programs to develop advanced IT skills among the Egyptian youth.',
                'Explore opportunities for closer collaboration with international technology companies like HCL.'
            ],
            'For Potential Partners (Local Tech Companies and Startups)': [
                'Actively explore collaboration opportunities with HCL to leverage their global reach and technological expertise.',
                'Focus on developing specialized skills and innovative solutions to complement HCL\'s service offerings.'
            ]
        },
        resources: [
            'https://www.founditgulf.com/job/business-analyst-hcltech-egypt-34009094',
            'https://www.hcltech.com/hcl-annual-report-2024/hcl-software.php',
            'https://www.trufla.com/blog/10-reasons-why-egypt-is-becoming-a-global-technology-hub/',
            'https://www.nucamp.co/blog/coding-bootcamp-egypt-egy-top-10-tech-companies-to-work-for-in-egypt-in-2025',
            'https://unity-connect.com/our-resources/news/egypt-gains-momentum-as-key-player-in-global-outsourcing-tech-scene/'
        ]
    }
};

const Section: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = "" }) => (
  <section className={`mb-12 ${className}`}>
    <h2 className="text-3xl font-bold text-navy mb-6 border-b-2 border-gray-200 pb-3">{title}</h2>
    <div className="space-y-4 text-gray-700 leading-relaxed text-lg">{children}</div>
  </section>
);


const ResearchDetailPage: React.FC = () => {
    const { researchId } = useParams<{ researchId: string }>();

    if (!researchId || !researchDetails[researchId as keyof typeof researchDetails]) {
        return (
             <div className="text-center py-20">
                <h1 className="text-4xl font-bold text-navy mb-4">Research Not Found</h1>
                <p className="text-lg text-gray-600 mb-8">The research you're looking for doesn't exist.</p>
                <Link to="/research" className="inline-block bg-soft-blue text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:bg-blue-600 transition-colors duration-300">
                    Back to Market Research
                </Link>
            </div>
        );
    }

    const research = researchDetails[researchId as keyof typeof researchDetails];

    return (
         <div className="py-20 bg-light-bg animate-fade-in">
            <div className="container mx-auto px-6">
                <div className="max-w-4xl mx-auto mb-6">
                    <Link to="/research" className="inline-flex items-center text-soft-blue font-semibold hover:text-navy transition-colors duration-300">
                        &larr; Back to All Market Research
                    </Link>
                </div>
                <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden">
                    <img src={research.headerImage} alt={research.title} className="w-full h-64 object-cover" />
                    <div className="p-8 md:p-12">
                        <span className="text-sm font-semibold text-soft-blue uppercase tracking-wider">{research.category}</span>
                        <h1 className="text-4xl md:text-5xl font-bold text-navy mt-2 mb-10">{research.title}</h1>
                        
                        <Section title="Introduction">
                            {research.introduction.map((p, i) => <p key={i}>{p}</p>)}
                        </Section>

                        {research.sections.map((section, index) => (
                             <Section title={section.title} key={index}>
                                {section.findings.map((finding, findIndex) => (
                                    <div key={findIndex} className="mb-4">
                                        <h4 className="text-xl font-semibold text-navy mb-2">{finding.heading}</h4>
                                        {finding.details && finding.details.map((detail, detailIndex) => (
                                            <p key={detailIndex} className="mb-2">{detail}</p>
                                        ))}
                                        {finding.subPoints && (
                                            <ul className="list-disc list-inside space-y-2 pl-4">
                                                {finding.subPoints.map((point, pointIndex) => (
                                                    <li key={pointIndex}>{point}</li>
                                                ))}
                                            </ul>
                                        )}
                                        {finding.table && (
                                            <div className="overflow-x-auto mt-4">
                                                <table className="w-full text-left text-sm border-collapse">
                                                    <thead>
                                                        <tr className="border-b-2 border-gray-300 bg-gray-100">
                                                            {finding.table.headers.map((header, headerIndex) => {
                                                                const isNumeric = finding.table.numericColumns?.includes(headerIndex);
                                                                const headerClasses = `p-3 font-semibold text-navy text-left ${isNumeric ? 'text-right' : ''}`;
                                                                return <th key={header} className={headerClasses}>{header}</th>;
                                                            })}
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {finding.table.rows.map((row, rowIndex) => (
                                                            <tr key={rowIndex} className="border-b border-gray-200 last:border-b-0 hover:bg-gray-50">
                                                                {row.map((cell, cellIndex) => {
                                                                    const isNumeric = finding.table.numericColumns?.includes(cellIndex);
                                                                    const cellClasses = `p-3 text-gray-700 ${isNumeric ? 'text-right' : ''}`;
                                                                    return <td key={cellIndex} className={cellClasses}>{cell}</td>;
                                                                })}
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        )}
                                    </div>
                                ))}
                                {section.resources && (
                                    <div className="mt-6">
                                        <h5 className="font-bold text-navy">Key Resources:</h5>
                                        <ul className="text-sm space-y-1 mt-2">
                                            {section.resources.map((link, linkIndex) => (
                                                <li key={linkIndex}>
                                                    <a href={link} target="_blank" rel="noopener noreferrer" className="text-soft-blue hover:underline break-all">
                                                        {link.length > 80 ? `${link.substring(0, 80)}...` : link}
                                                        <ExternalLinkIcon className="w-4 h-4 inline-block ml-1" />
                                                    </a>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </Section>
                        ))}

                        <Section title="Conclusion">
                            <div className="border-l-4 border-soft-blue pl-6 italic space-y-4">
                                {research.conclusion.split('\n').map((p, i) => <p key={i}>{p}</p>)}
                            </div>
                        </Section>
                        
                        {research.recommendations && (
                            <Section title="Recommendations">
                                {Object.entries(research.recommendations).map(([key, value]) => (
                                    <div key={key} className="mb-4">
                                        <h4 className="text-xl font-semibold text-navy mb-2">{key}</h4>
                                        <ul className="list-disc list-inside space-y-2 pl-4">
                                            {value.map((rec, recIndex) => (
                                                <li key={recIndex}>{rec}</li>
                                            ))}
                                        </ul>
                                    </div>
                                ))}
                            </Section>
                        )}
                        
                        {research.resources && (
                             <Section title="References">
                                <ul className="text-sm space-y-1 mt-2">
                                    {research.resources.map((link, linkIndex) => (
                                        <li key={linkIndex}>
                                            <a href={link} target="_blank" rel="noopener noreferrer" className="text-soft-blue hover:underline break-all">
                                                {`[${linkIndex+1}] ${link}`}
                                                <ExternalLinkIcon className="w-4 h-4 inline-block ml-1" />
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </Section>
                        )}


                         <div className="mt-16 text-center border-t pt-8">
                            <Link to="/research" className="inline-block text-soft-blue font-semibold hover:text-blue-600 transition-colors duration-300">
                                &larr; Back to All Market Research
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ResearchDetailPage;